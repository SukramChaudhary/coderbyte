## Brief:

A client has come to us wanting some updates to their dog sitting website. Our designer has provided some changes for you to use. You’ll need to create these sections so that they are responsive across different screen sizes, you have designs for mobile, tablet and desktop views. 
Please try to spend no more than 2 hours to complete both of these sections.

 

## Instructions:

We’ve given you a zip file with some of the assets and some basic html

Grab that and complete the design found in Zeplin (Link and login details above).

Try to do each thing well, it’s better to have half done perfectly, than rush it.



Retrieve here: https://github.com/BlackSheepCreative/DevTest


Submit a link to a public repo with your attempt or zip it up and email it through.
